tinymce.addI18n('es',{
	'SH4TinyMCE - Code Editor'	: 'SH4TinyMCE - Code Editor',
	'Insert/Edit Code'			: 'Insertar/Editar Codigo',
	'Language'					: 'Lenguaje',
	'Auto links'				: 'Auto links',
	'Gutter'					: 'Gutter',
	'Html script'				: 'HTML script',
	'Toolbar'					: 'Toolbar',
	'Highlight'					: 'Highlight',
	'Tab size'					: 'Tab size',
	'First Line'				: 'First Line',
});